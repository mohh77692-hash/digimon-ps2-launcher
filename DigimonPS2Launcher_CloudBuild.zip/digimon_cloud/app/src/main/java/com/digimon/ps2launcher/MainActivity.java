package com.digimon.ps2launcher;
import android.app.*; import android.os.*; import android.content.*; import android.content.pm.*; import android.net.Uri; import android.graphics.Color; import android.graphics.Typeface; import android.graphics.drawable.GradientDrawable; import android.view.Gravity; import android.widget.*;
public class MainActivity extends Activity {
 static final int PICK=4102; static final String PREF="digimon_launcher", KEY="game_uri";
 final String[] pkgs={"xyz.aethersx2.android","xyz.aethersx2.android.debug","xyz.aethersx2.android.patched","xyz.aethersx2.android.nightly"};
 Uri game; TextView status,chosen; int bg=0xFF101020,panel=0xFF1E1C33,purple=0xFF4C3087;
 GradientDrawable shape(int c,int r){GradientDrawable d=new GradientDrawable();d.setColor(c);d.setCornerRadius(r);return d;}
 TextView txt(String s,int z,int c,boolean b){TextView t=new TextView(this);t.setText(s);t.setTextSize(z);t.setTextColor(c);if(b)t.setTypeface(Typeface.DEFAULT,1);return t;}
 Button btn(String s,int c){Button b=new Button(this);b.setText(s);b.setTextColor(-1);b.setTextSize(15);b.setAllCaps(false);b.setBackground(shape(c,18));return b;}
 public void onCreate(Bundle b){super.onCreate(b);String u=getSharedPreferences(PREF,0).getString(KEY,null);if(u!=null)game=Uri.parse(u);ui();}
 void ui(){
  ScrollView sc=new ScrollView(this);sc.setBackgroundColor(bg);LinearLayout root=new LinearLayout(this);root.setPadding(22,26,22,26);root.setOrientation(1);sc.addView(root);
  root.addView(txt("DIGIMON",30,-1,true));root.addView(txt("PS2 MOBILE LAUNCHER",12,0xFFC5B8FF,true));
  LinearLayout hero=new LinearLayout(this);hero.setPadding(18,22,18,22);hero.setOrientation(1);hero.setBackground(shape(purple,24));LinearLayout.LayoutParams hp=new LinearLayout.LayoutParams(-1,-2);hp.topMargin=22;root.addView(hero,hp);
  hero.addView(txt("RUMBLE ARENA 2",24,-1,true));hero.addView(txt("PLAYSTATION 2 EDITION",12,0xFFE1D9FF,false));
  Button pick=btn("PILIH FILE GAME (.ISO / .CHD)",0xFF514080);LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(-1,54);p.topMargin=22;hero.addView(pick,p);pick.setOnClickListener(v->pickGame());
  chosen=txt(game==null?"Game: belum dipilih":"Game: "+game.getLastPathSegment(),12,0xFFE1D9FF,false);LinearLayout.LayoutParams cp=new LinearLayout.LayoutParams(-1,-2);cp.topMargin=10;hero.addView(chosen,cp);
  Button play=btn("▶  MAIN SEKARANG",0xFF248A62);LinearLayout.LayoutParams pp=new LinearLayout.LayoutParams(-1,58);pp.topMargin=14;hero.addView(play,pp);play.setOnClickListener(v->launchGame());
  LinearLayout info=card(root,"INFORMASI PERANGKAT");line(info,"Perangkat","Redmi Note 13 Pro 5G");line(info,"RAM","8 GB");line(info,"Chipset","Snapdragon 7s Gen 2");line(info,"Game","Digimon Rumble Arena 2");
  LinearLayout cfg=card(root,"PENGATURAN YANG DISARANKAN");line(cfg,"Renderer awal","Vulkan");line(cfg,"Resolusi awal","1x Native");line(cfg,"Catatan","Atur di emulator; uji stabilitas");
  status=txt("Status: pilih file game untuk memulai",13,0xFFBDB8D3,false);LinearLayout.LayoutParams sp=new LinearLayout.LayoutParams(-1,-2);sp.topMargin=18;root.addView(status,sp);
  TextView note=txt("Launcher mengirim URI file game ke emulator. BIOS PS2 dan file game harus kamu sediakan sendiri dari salinan yang sah.",11,0xFF9993B2,false);note.setPadding(0,18,0,0);root.addView(note);setContentView(sc);
 }
 LinearLayout card(LinearLayout r,String h){LinearLayout b=new LinearLayout(this);b.setOrientation(1);b.setPadding(16,16,16,16);b.setBackground(shape(panel,20));LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(-1,-2);p.topMargin=18;r.addView(b,p);b.addView(txt(h,14,-1,true));return b;}
 void line(LinearLayout b,String l,String v){LinearLayout r=new LinearLayout(this);r.setGravity(Gravity.CENTER_VERTICAL);r.setPadding(0,10,0,4);r.addView(txt(l,13,0xFFC5C1D8,false),new LinearLayout.LayoutParams(0,-2,1));r.addView(txt(v,13,-1,true));b.addView(r);}
 void pickGame(){Intent i=new Intent(Intent.ACTION_OPEN_DOCUMENT);i.addCategory(Intent.CATEGORY_OPENABLE);i.setType("*/*");i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION|Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION);startActivityForResult(i,PICK);}
 protected void onActivityResult(int req,int res,Intent d){super.onActivityResult(req,res,d);if(req==PICK&&res==RESULT_OK&&d!=null&&d.getData()!=null){game=d.getData();try{getContentResolver().takePersistableUriPermission(game,d.getFlags()&Intent.FLAG_GRANT_READ_URI_PERMISSION);}catch(Exception ignored){}getSharedPreferences(PREF,0).edit().putString(KEY,game.toString()).apply();chosen.setText("Game: "+game.getLastPathSegment());status.setText("Status: file game dipilih; siap dicoba");}}
 void launchGame(){
  if(game==null){status.setText("Pilih file game terlebih dahulu");pickGame();return;}
  PackageManager pm=getPackageManager();
  for(String pkg:pkgs){try{Intent i=new Intent(Intent.ACTION_MAIN);i.setComponent(new ComponentName(pkg,pkg+".EmulationActivity"));i.putExtra("bootPath",game.toString());i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK|Intent.FLAG_GRANT_READ_URI_PERMISSION);i.setClipData(ClipData.newUri(getContentResolver(),"PS2 game",game));if(i.resolveActivity(pm)!=null){status.setText("Membuka Digimon Rumble Arena 2…");startActivity(i);return;}}catch(Exception ignored){}}
  for(String pkg:pkgs){Intent home=pm.getLaunchIntentForPackage(pkg);if(home!=null){status.setText("Emulator ditemukan; direct launch tidak cocok. Pilih game dari emulator.");startActivity(home);return;}}
  status.setText("NetherSX2 belum ditemukan. Pasang emulator terlebih dahulu.");
  new AlertDialog.Builder(this).setTitle("Emulator belum ditemukan").setMessage("Pasang NetherSX2 Classic/AetherSX2 yang kompatibel. Build tertentu mungkin memakai package ID berbeda.").setPositiveButton("Mengerti",null).show();
 }
}